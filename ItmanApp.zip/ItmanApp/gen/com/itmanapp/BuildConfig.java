/** Automatically generated file. DO NOT MODIFY */
package com.itmanapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}