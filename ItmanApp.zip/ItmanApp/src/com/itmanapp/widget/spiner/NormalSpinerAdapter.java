package com.itmanapp.widget.spiner;

import android.content.Context;

/**
 * 列表下拉框选择控件适配器
 * 
 * @created 2014-8-11
 */
public class NormalSpinerAdapter extends AbstractSpinerAdapter<String>{

	public  NormalSpinerAdapter(Context context){
		super(context);
	}
}
